package com.duoc.entidades;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Sep 2, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Formativa Semana04 - Grupo11
 *
 */
public class Inventario {

    private HashMap<String, Producto> productos;

    public Inventario() {
        productos = new HashMap<>();
    }

    //Método para agregar produtos al inventario
    public void agregarProducto(Producto producto) {
        productos.put(producto.getCodigo(), producto);
    }

    //Método buscar productos por codigo
    public Producto buscarProducto(String codigo) {
        return productos.get(codigo);
    }

    // Método para eliminar productos del inventario
    public void eliminarProducto(String codigo) {
        productos.remove(codigo);
    }

    public boolean validarDatos(Producto producto) {
        return producto.getPrecio() >= 0; // Validar que el precio sea positivo
    }
    
    //Método para generar infromes del inventario
    public List<Producto> generarInforme(){
        return new ArrayList<>(productos.values());
    }
    
    //Método valida datos del producto
    //public boolean validarDatos(Producto producto) {
//        return  producto.getPrecio() <= 0;  //Valida que el precio sea positivo
//    }
}
