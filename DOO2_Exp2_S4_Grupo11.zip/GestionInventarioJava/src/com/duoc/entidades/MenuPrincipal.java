package com.duoc.entidades;

import java.util.List;
import java.util.Scanner;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Sep 2, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Formativa Semana04 - Grupo11
 *
 */
public class MenuPrincipal {

    private static Inventario inventario = new Inventario();
    private static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        do {
            menuPri();
            //Validacion de opcion ingresada sea correcta
            try {
                opcion = teclado.nextInt();
            } catch (Exception e) {
                System.out.println("*** Opcion No valida ***");
                opcion = 0;
                teclado.next(); //Limpiamos el buffer del scanner
            }
            switch (opcion) {
                case 1 ->
                    agregarProducto();
                case 2 ->
                    eliminarProducto();
                case 3 ->
                    buscarProducto();
                case 4 ->
                    listarInventario();
                case 5 ->
                    System.out.println("Gracias por su visita, Adios.");
                default ->
                    System.out.println("Opcion fuera de rango.\n");
            }

        } while (opcion != 5);
        teclado.close();
    }

    static void menuPri() {
        String s = """
                  ------:Menu Principal - Inventario:------
                  1. Agregar Productos.
                  2. Eliminar Productos.
                  3. Buscar Productos.
                  4. Listar Inventario.
                  5. Salir
                  Seleccione su opcion:
                   """;
        System.out.println(s);
    }

    private static void agregarProducto() {
        System.out.print("Ingrese el codigo del Producto:");
        teclado.next(); //limpiar buffer
        String codigo = teclado.nextLine();
        System.out.print("Ingrese el nombre del producto:");
        String nombre = teclado.nextLine();
        System.out.print("Ingrese el precio del producto:");
        double precio = teclado.nextDouble();
        teclado.nextLine(); //limpiar el buffer

        Producto producto = new Producto(codigo, nombre, precio);
        if (inventario.validarDatos(producto)) {
            inventario.agregarProducto(producto);
            System.out.println("Producto agregado con Exito");
        } else {
            System.out.println("Datos producto invalidos.");
        }
    }

    private static void eliminarProducto() {
        System.out.print("Ingrese el codigo del producto a ELIMINAR: ");
        String codigo = teclado.nextLine();
        inventario.eliminarProducto(codigo);
        System.out.println("Producto eliminado.");
    }

    private static void buscarProducto() {
        System.out.print("Ingrese el codigo del producto a buscar:");
        String codigo = teclado.nextLine();
        Producto producto = inventario.buscarProducto(codigo);
        if (producto != null) {
            System.out.print("Porudcto Existe: " + producto);
        }
    }

    private static void listarInventario() {
        List<Producto> productos = inventario.generarInforme();
        if (productos.isEmpty()) {
            System.out.println("El inventario esta vacio.");
        } else {
            System.out.println("Listado de productos del inventario");
            for (Producto producto : productos) {
                System.out.println(producto);
            }
        }
    }
}
