
package com.duoc.entidades;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Sep 2, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Formativa Semana04 - Grupo11
 *
 */
public class Producto {
    private String codigo;
    private String nombre;
    private double precio;
    
    //Constructor
    public Producto() {
    }

    public Producto(String codigo, String nombre, double precio) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
    }
    
    //Getters & Setters
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    //Método actualiza precio del producto
    public void actualizaPrecio(double nuevoPrecio) {
        this.precio = nuevoPrecio;
    }
    
    //Método Descripcion detallada del producto
    @Override
    public String toString() {
        return "Codigo: " + codigo + ", Nombre: " + nombre + ", Precio: " + precio;
    }
}
